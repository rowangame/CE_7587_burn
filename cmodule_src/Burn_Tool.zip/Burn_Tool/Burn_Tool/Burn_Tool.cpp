﻿/* ats_uart.c: ats uart command test
 * Author: Jiang Zhuangwei <jiangzw@3nod.com.cn>
 */

#pragma warning(disable : 4996)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>
#include <signal.h>
#include <string.h>

#include "libserialport.h"
#include "ats_cmd.h"
#include "mcs_fwu.h"
#include "mm_share.h"

#define VERSION			"0.1.3"

int ats_uart_read(void* buf, int len);
int ats_uart_write(const void* buf, int len);
int ats_uart_send_ack(const void* buf, int len, void* ack, int ack_len);

#define DEBUG	1
#ifdef DEBUG
#define dbg(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
#define dbg(fmt, ...) do {} while (0)
#endif
#define msg(fmt, ...) printf(fmt, ##__VA_ARGS__)

#define ATS_UART_BAUDRATE	921600
#define ATS_UART_DATA_BITS	8
#define ATS_UART_STOP_BITS	1
#define ATS_UART_PARITY		SP_PARITY_NONE
#define ATS_UART_FLOW_CTRL	SP_FLOWCONTROL_NONE

#define MAX_BUF_LEN		    128
#define WAIT_ACK_TIMEOUT	    3000
#define WAIT_RESPONSE_TIMEOUT	3000
#define READ_WRITE_TIMEOUT	3000
#define DEMO_ERASE_TIMEOUT	20000

#define MSG_INFO          1     
#define MSG_ERROR         2
#define MSG_EXCEPT        3
#define MSG_PROGRESS      4
#define MSG_BURN_STATE    5

#define BURN_STATE_INIT            0
#define BURN_STATE_START           1
#define BURN_STATE_REQ_BURN        2
#define BURN_STATE_DATA_TRANSFER   3
#define BURN_STATE_DATA_FINISH     4
#define BURN_STATE_REQ_END         5
#define BURN_STATE_END_SUCCESS     6
#define BURN_STATE_END_FAIL        7

#define MSG_BURN_FAIL "烧入失败!"
#define MSG_BURN_SUCCESS "烧入成功!"


typedef struct ats_uart {
	char* name;
	struct sp_port* port;
	struct sp_event_set* event;
	int baudrate;
	int data_bits;
	int stop_bits;
	enum sp_parity parity;
	enum sp_flowcontrol flow_ctrl;
} ats_uart_t;

typedef struct fw_info {
	char* name;
	char* buf;
	long size;
	uint8_t sum;
} fw_info_t;

static volatile int is_aborting = 0;
static struct sp_port* ats_port;
static struct sp_event_set* ats_event;
static struct fw_info fw_info;

static char* ats_cmd = NULL;
static char* port_name = NULL;
static char* fw_name = NULL;
static int baudrate = ATS_UART_BAUDRATE;
static int binTypeValue = 0;
static char* mmShareName = NULL;
static MyShareProxy mShareProxy;
static bool mIsEnd = false;

static void signal_handler(int signal)
{
	if (!is_aborting)
		is_aborting = 1;
}

static void usage(const char* cmd)
{
	printf("Usage: %s [cmd]...[opts]...\n"
		"\n"
		"-h, --help              help\n"
		"-v, --version           print current version\n"
		"-l, --list-ports        list all serial ports\n"
		"-p, --port=#PORT        seiral port name, example: COM0\n"
		"-b, --baudrate=#RATE    specify baud rate, default is 921600\n"
		"-c, --cmd=#COMMAND      ats command\n"
		"-u, --upgrade=#NAME     firmware upgrade\n"
		, cmd);
}

void my_printf(const char* format, ...) {
	char tmpBuffer[128];
	memset(tmpBuffer, 0, sizeof(tmpBuffer));

	// 使用 va_list 来处理可变参数
	va_list args;
	va_start(args, format);
	
	vprintf(format, args);
	vsnprintf(tmpBuffer, sizeof(tmpBuffer), format, args);
	
	if (mShareProxy.isInitialized()) {
		// 向写入到共享数据中
		int tmpLen = strlen(tmpBuffer);
		mShareProxy.writeMMData(tmpBuffer, tmpLen, mIsEnd);
	}

	va_end(args);
}

void showBurnState(int bsState) {
	my_printf("#<%d>state=%d\n", MSG_BURN_STATE, bsState);
}

void endBurnProcess(int errorTag, const char* errorMsg) {
	if (errorTag != 0) {
		my_printf("#<%d>%s\n", MSG_ERROR, errorMsg);
		// 这里设置共享内存缓存区结束状态
		mIsEnd = true;
		showBurnState(BURN_STATE_END_FAIL);
	}
	else {
		my_printf("#<%d>%s\n", MSG_INFO, errorMsg);
		// 这里设置共享内存缓存区结束状态
		mIsEnd = true;
		showBurnState(BURN_STATE_END_SUCCESS);
	}
}


uint8_t make_fw_sum(const uint8_t* data, uint32_t size) {
	int i;
	unsigned char sum = 0;

	for (i = 0; i < size; i++) {
		sum += data[i];
	}

	return (~sum + 1) & 0xff;
}

uint8_t make_sum(const uint8_t* data, uint32_t size)
{
	int i;
	uint8_t sum = 0;

	for (i = 0; i < size; i++) {
		sum ^= data[i];
	}

	return sum;
}

int load_fw(const char* name)
{
	long size = 0;
	char* buf;
	struct fw_info* fw = &fw_info;

	FILE* fp = fopen(name, "rb");
	if (!fp) return -1;

	fseek(fp, 0, SEEK_END);
	size = ftell(fp);
	buf = (char*)calloc(1, size);
	if (!buf) {
		fclose(fp);
		return -1;
	}

	fseek(fp, 0, SEEK_SET);
	fread(buf, 1, size, fp);
	fclose(fp);

	fw->name = (char*)name;
	fw->buf = buf;
	fw->size = size;
	fw->sum = make_fw_sum((const uint8_t*)buf, size);

	my_printf("#<%d>加载固件文件成功,size=%ld,sum=0x%02x\n", MSG_INFO, fw->size, fw->sum);
	return 0;
}

int fwu_start(void)
{
	struct fwu_init_packet packet;
	struct fwu_init_packet* p = &packet;
	struct fwu_header* h = &p->header;
	struct fwu_ack_packet ack;
	struct fw_info* fw = &fw_info;
	int ret, len;
	uint8_t sum = 0;

	len = sizeof(*p);
	memset(p, 0, len);
	h->sync_byte = SYNC_BYTE;
	h->pack_type = PACK_CMD;
	h->major_id = ID_UPGRADE_CTRL_CMD;
	h->minor_id = CMD_UPGRADE_START;
	h->length = len - sizeof(*h) - 1;
	p->fw_size[0] = (uint8_t)(fw->size >> 16);
	p->fw_size[1] = (uint8_t)(fw->size >> 8);
	p->fw_size[2] = (uint8_t)(fw->size);
	p->fw_checksum = fw->sum;
	p->data_len[0] = (uint8_t)(FWU_MAX_DATA_LEN >> 8);
	p->data_len[1] = (uint8_t)(FWU_MAX_DATA_LEN);
	// 这里需要根据类型文件(由调用者进程传替)来配置参数值
	//p->upgrade_type = UPGRADE_TYPE_MAIN_FW;
	p->upgrade_type = binTypeValue;
	p->checksum = make_sum((const uint8_t*)p, len - 1);

	if (binTypeValue == UPGRADE_TYPE_DEMO) {
		ret = ats_uart_write((const void*)p, len);
		if (ret != len) {
			fprintf(stderr, "Failed to write %d bytes data\n", len);
			return -1;
		}

		//wait erase flash, about 12s
		msg("Data is erasing, please wait...\n");
		int ack_len = sizeof(ack);
		memset(&ack, 0, ack_len);
		ret = sp_blocking_read(ats_port, (void*)&ack, ack_len, READ_WRITE_TIMEOUT + DEMO_ERASE_TIMEOUT);
		if (ret != sizeof(ack)) {
			fprintf(stderr, "Failed to read %d bytes data\n", ack_len);
			return -1;
		}
	}
	else {
		ret = ats_uart_send_ack((const void*)p, len, &ack, sizeof(ack));
		if (ret < 0) {
			return -1;
		}
	}

	if (ack.header.sync_byte == SYNC_BYTE &&
		ack.header.pack_type == 0x52) {
		//drop response, wait ack
		ret = ats_uart_read(&ack, sizeof(ack));
		if (ret < 0) {
			return -1;
		}
	}

	char* s = (char*)&ack;
	my_printf("#<%d>请求开始烧入状态: %02x %02x %02x %02x %02x %02x %02x\n", MSG_INFO, s[0], s[1], s[2], s[3], s[4], s[5], s[6]);

	sum = make_sum((const uint8_t*)&ack, sizeof(ack) - 1);
	h = &ack.header;
	if (ack.header.sync_byte == SYNC_BYTE &&
		ack.header.pack_type == PACK_IND &&
		ack.header.major_id == ID_UPGRADE_INDICATOR &&
		ack.header.minor_id == IND_UPGRADE_STATE_CHANGE &&
		ack.header.length == 1 &&
		ack.state == IND_UPGRADE_STATE_CHANGE &&
		ack.checksum == sum) {
		my_printf("#<%d>请求开始烧入状态:完成\n", MSG_INFO);
		return 0;
	}

	my_printf("#<%d>请求开始烧入状态失败,状态码:0x%x\n", MSG_ERROR, ack.state);
	return -1;
}

int  fwu_end(void)
{
	struct fwu_end_packet packet;
	struct fwu_end_packet* p = &packet;
	struct fwu_header* h = &p->header;
	struct fwu_ack_packet ack;
	int ret, len;
	uint8_t sum = 0;

	len = sizeof(*p);
	memset(p, 0, sizeof(*p));
	h->sync_byte = SYNC_BYTE;
	h->pack_type = PACK_CMD;
	h->major_id = ID_UPGRADE_CTRL_CMD;
	h->minor_id = CMD_UPGRADE_DATA_TRANSFER_END; //Upgrade end
	h->length = 0;
	p->checksum = make_sum((const uint8_t*)p, len - 1);

	ret = ats_uart_send_ack((const void*)p, len, &ack, sizeof(ack));
	if (ret < 0) {
		return -1;
	}

	if (ack.header.sync_byte == SYNC_BYTE &&
		ack.header.pack_type == PACK_IND &&
		ack.header.major_id == ID_UPGRADE_INDICATOR &&
		ack.header.minor_id == IND_UPGRADE_DATA_TRANSFER_END) {
		my_printf("#<%d>固件数据传输结束,返回状态值:0x%x\n", MSG_INFO, ack.state);
		//wait ack
		my_printf("#<%d>请求烧入结果状态数据\n", MSG_INFO);
		ret = ats_uart_read(&ack, sizeof(ack));
		if (ret < 0) {
			my_printf("#<%d>请求烧入结果状态数据失败\n", MSG_INFO);
			return -1;
		}
	}

	char* s = (char*)&ack;
	my_printf("#<%d>烧入结果状态数据:%02x %02x %02x %02x %02x %02x %02x\n",  MSG_INFO, s[0], s[1], s[2], s[3], s[4], s[5], s[6]);

	sum = make_sum((const uint8_t*)&ack, sizeof(ack) - 1);
	if (ack.header.sync_byte == SYNC_BYTE &&
		ack.header.pack_type == PACK_IND &&
		ack.header.major_id == ID_UPGRADE_INDICATOR &&
		ack.header.minor_id == IND_UPGRADE_STATE_CHANGE &&
		ack.header.length == 0x1 &&
		ack.state == IND_UPGRADE_COMPLETE &&
		ack.checksum == sum) {
		my_printf("#<%d>烧入完成\n", MSG_INFO);
		return 0;
	}

	my_printf("#<%d>烧入失败,烧入结果状态码:0x%x\n", MSG_ERROR, ack.state);
	return -1;
}

int  fwu_data_transfer(void)
{
	struct fwu_data_packet packet;
	struct fwu_data_packet* p = &packet;
	struct fwu_data_header* h = &p->header;
	struct fwu_data_ack_packet ack;
	struct fw_info* fw = &fw_info;
	char* ptr = fw->buf;
	int ret, len, try_count = 0;
	uint8_t sum = 0;

	len = sizeof(*p);
	memset(p, 0, sizeof(*p));
	h->sync_byte = SYNC_BYTE;
	h->pack_type = PACK_DATA;
	h->major_id = DATA_SOURCE_UART;
	h->minor_id = 0x00;

	int left = fw->size;
	int offset = 0;
	int percent = 0;
	while (left > 0 && try_count < 1) {
		int size = left > FWU_MAX_DATA_LEN ? FWU_MAX_DATA_LEN : left;
		memcpy(p->data, ptr + offset, size);

		len = size + 2; //data size + reserved 2 bytes
		h->length[0] = (uint8_t)(len >> 8);
		h->length[1] = (uint8_t)len;

		len += sizeof(struct fwu_data_header);
		sum = make_sum((const uint8_t*)p, len);
		if (size == FWU_MAX_DATA_LEN)
			p->checksum = sum;
		else
			p->data[size] = sum; //checksum follows the data.

		len += 1; //add checksum

		ret = ats_uart_send_ack((const void*)p, len, &ack, sizeof(ack));
		if (ret < 0) {
			my_printf("#<%d>请求数据同步结果状态:失败!\n", MSG_ERROR);
			goto retry;
		}

		//char *s = (char *)&ack;
		//dbg("%s ack: %02x %02x %02x %02x %02x %02x %02x\n",
		//	__func__, s[0], s[1], s[2], s[3], s[4], s[5], s[6]);

		sum = make_sum((const uint8_t*)&ack, sizeof(ack) - 1);
		if (ack.header.sync_byte == SYNC_BYTE &&
			ack.header.pack_type == PACK_IND &&
			ack.header.major_id == ID_UPGRADE_INDICATOR &&
			ack.header.minor_id == IND_UPGRADE_ACK &&
			ack.header.length == 0x2 &&
			ack.checksum == sum) {
			//dbg("Upgrading ACK, left %d/%lu bytes\n", left, fw->size);

			offset += size;
			left -= size;

			int value = offset * 100 / fw->size;
			if (value != percent) {
				percent = value;
				my_printf("#<%d>Upgrading:<%d%%>\n", MSG_PROGRESS, percent);
			}
			continue;
		}

	retry:
		//data transfer failed, retry
		try_count++;
		my_printf("#<%d>重新尝试传输数据,重试次数=%d\n", MSG_INFO, try_count);
	}

	if (left > 0) {
		my_printf("#<%d>固件数据传输出错,剩余:%d!\n", MSG_ERROR, left);
		return -1;
	}

	my_printf("#<%d>固件数据传输完成\n", MSG_INFO);
	return 0;
}

int ats_uart_list_port(void)
{
	struct sp_port** port_list;
	enum sp_return result = sp_list_ports(&port_list);

	if (result != SP_OK) {
		fprintf(stderr, "Error: list ports failed!\n");
		return -1;
	}

	/* Iterate through the ports. When port_list[i] is NULL
	 * this indicates the end of the list. */
	int i;
	for (i = 0; port_list[i] != NULL; i++) {
		struct sp_port* port = port_list[i];

		/* Get the name of the port. */
		char* port_name = sp_get_port_name(port);

		printf("Found port: %s\n", port_name);
	}

	sp_free_port_list(port_list);
	return 0;
}

void ats_uart_dump_config(struct sp_port* port)
{
	struct sp_port_config* config;
	int baudrate, bits, stopbits;
	enum sp_parity parity;

	sp_new_config(&config);
	sp_get_config(port, config);
	sp_get_config_baudrate(config, &baudrate);
	sp_get_config_bits(config, &bits);
	sp_get_config_stopbits(config, &stopbits);
	sp_get_config_parity(config, &parity);
	dbg("Baudrate: %d, data bits: %d, parity: %d, stop bits: %d\n",
		baudrate, bits, parity, stopbits);

	sp_free_config(config);
}

struct sp_port* ats_uart_init(const char* port_name)
{
	struct sp_port* port = NULL;
	enum sp_return ret;

	ret = sp_get_port_by_name(port_name, &port);
	if (ret != SP_OK) {
		// fprintf(stderr, "Error: Get port '%s' failed, ret=%d", port_name, ret);
		my_printf("#<%d>得到串口号类型失败,状态码:%d\n", MSG_ERROR, ret);
		return NULL;
	}

	/* Display some basic information about the port. */
	//dbg("Port name: %s\n", sp_get_port_name(port));
	//dbg("Description: %s\n", sp_get_port_description(port));

	ret = sp_open(port, SP_MODE_READ_WRITE);
	if (ret != SP_OK) {
		// fprintf(stderr, "Error: Open port failed, ret=%d", ret);
		my_printf("#<%d>打开串口失败,状态码:%d\n", MSG_ERROR, ret);
		sp_free_port(port);
		return NULL;
	}

	//dbg("Setting port to 921600 8N1, no flow control.\n");
	sp_set_baudrate(port, ATS_UART_BAUDRATE);
	sp_set_bits(port, ATS_UART_DATA_BITS);
	sp_set_parity(port, ATS_UART_PARITY);
	sp_set_stopbits(port, ATS_UART_STOP_BITS);
	sp_set_flowcontrol(port, ATS_UART_FLOW_CTRL);

	ats_uart_dump_config(port);

	return port;
}

void ats_uart_release(void)
{
	if (ats_port) {
		sp_close(ats_port);
		sp_free_port(ats_port);
		ats_port = NULL;
	}
}

int ats_uart_wait_input(int timeout)
{
	struct sp_port* port = ats_port;
	struct sp_event_set* event_set = ats_event;
	int bytes = 0;

	sp_wait(event_set, timeout);
	bytes = sp_input_waiting(port);
	if (bytes > 0) {
		//dbg("%d bytes received.\n", bytes);
	}

	if (bytes > MAX_BUF_LEN) {
		sp_flush(port, SP_BUF_INPUT);
		fprintf(stderr, "Error: Input %d bytes too large\n", bytes);
		return 0;
	}

	return bytes;
}

int ats_uart_write(const void* buf, int len)
{
	int ret = sp_blocking_write(ats_port, buf, len, READ_WRITE_TIMEOUT);
	if (ret != len) {
		fprintf(stderr, "Error: Send %d of %d bytes timeout\n", ret, len);
	}

	return ret;
}

int ats_uart_read(void* buf, int len)
{
	int ret = sp_blocking_read(ats_port, buf, len, READ_WRITE_TIMEOUT);
	if (ret != len) {
		fprintf(stderr, "Error: Recieve %d of %d bytes timeout\n", ret, len);
	}

	return ret;
}

int ats_uart_send_ack(const void* buf, int len, void* ack, int ack_len)
{
	int ret;

	ret = ats_uart_write(buf, len);
	if (ret != len) {
		fprintf(stderr, "Failed to write %d bytes data\n", len);
		return -1;
	}

	memset(ack, 0, ack_len);
	ret = ats_uart_read(ack, ack_len);
	if (ret != ack_len) {
		fprintf(stderr, "Failed to read %d bytes data\n", ack_len);
		return -1;
	}

	return 0;
}

int ats_uart_wait_ack(char* ack, int* ack_len, int timeout)
{
	int ret, bytes;

	bytes = ats_uart_wait_input(timeout);
	if (bytes == 0 || bytes > *ack_len) {
		return -1;
	}

	memset(ack, 0, *ack_len);
	ret = ats_uart_read(ack, bytes);
	if (ret != bytes) {
		return -1;
	}

	*ack_len = ret;
	return 0;
}

int ats_uart_cmd_ack(const char* cmd, char* ack, int* ack_len)
{
	int ret, len;
	char buf[MAX_BUF_LEN] = { 0 };

	dbg("Send command '%s'\n", cmd);
	snprintf(buf, sizeof(buf), "%s\n", cmd);
	len = strlen(buf);
	ret = ats_uart_write(buf, len);
	if (ret != len) {
		//fprintf(stderr, "Error: %d/%d bytes sent", ret, len);
		return -1;
	}

	ret = ats_uart_wait_ack(ack, ack_len, WAIT_ACK_TIMEOUT); 
	if (ret < 0) {
		fprintf(stderr, "Error: wait ack timeout\n");
		return -1;
	}

	msg("%s", ack);
	return 0;
}

int process_ats_command(void)
{
	struct sp_port* port = NULL;
	char ack[MAX_BUF_LEN] = { 0 };
	int ret, len;

	if (port_name == NULL) {
		fprintf(stderr, "Error: Plsease specify serial port\n");
		return -1;
	}

	if (ats_cmd == NULL) {
		fprintf(stderr, "Error: Plsease specify ATS command\n");
		return -1;
	}

	port = ats_uart_init(port_name);
	if (!port) {
		ret = -1;
		goto exit;
	}

	ats_port = port;
	sp_new_event_set(&ats_event);
	sp_add_port_events(ats_event, port, SP_EVENT_RX_READY);

	//ATS command mode
	len = sizeof(ack);
	ret = ats_uart_cmd_ack(ats_cmd, ack, &len);
	if (ret < 0)
		goto exit;

	//listen key input
	if (!strcmp(ats_cmd, TL_KEY_IN)) {
		while (!is_aborting) {
			len = sizeof(ack);
			ret = ats_uart_wait_ack(ack, &len, WAIT_ACK_TIMEOUT);
			if (ret < 0)
				continue;

			msg("%s", ack);
		}

		len = sizeof(ack);
		ats_uart_cmd_ack(TL_KEY_OFF, ack, &len);
	}

exit:
	if (ats_event)
		sp_free_event_set(ats_event);

	ats_uart_release();
	return ret;
}

int process_fw_upgrade(void)
{
	struct sp_port* port = NULL;
	int ret;

	if (port_name == NULL) {
		my_printf("#<%d>请确认串口号类型!\n", MSG_ERROR);
		endBurnProcess(-1, MSG_BURN_FAIL);
		return -1;
	}

	if (fw_name == NULL) {
		my_printf("#<%d>请确认固件文件类型!\n", MSG_ERROR);
		endBurnProcess(-1, MSG_BURN_FAIL);
		return -1;
	}

	port = ats_uart_init(port_name);
	if (!port) {
		my_printf("#<%d>串口对象初始化失败!\n", MSG_ERROR);
		endBurnProcess(-1, MSG_BURN_FAIL);
		ret = -1;
		goto exit;
	}

	ats_port = port;

	
	my_printf("#<%d>加载固件文件!\n", MSG_INFO);
	ret = load_fw(fw_name);
	if (ret < 0) {
		my_printf("#<%d>加载固件文件失败!\n", MSG_ERROR);
		goto exit;
	}

	showBurnState(BURN_STATE_REQ_BURN);
	ret = fwu_start();
	if (ret < 0) {
		my_printf("#<%d>执行开始烧入逻辑失败!\n", MSG_ERROR);
		goto exit;
	}

	showBurnState(BURN_STATE_DATA_TRANSFER);
	my_printf("#<%d>开始传输数据,总长度:%ld\n", MSG_INFO, fw_info.size);
	ret = fwu_data_transfer();
	if (ret < 0) {
		my_printf("#<%d>固件数据传输失败!\n", MSG_ERROR);
		goto exit;
	}
	showBurnState(BURN_STATE_DATA_FINISH);

	showBurnState(BURN_STATE_REQ_END);
	my_printf("#<%d>执行结束烧入逻辑\n", MSG_INFO);
	ret = fwu_end();
	if (ret < 0) {
		my_printf("#<%d>执行结束烧入逻辑失败!\n", MSG_ERROR);
		goto exit;
	}
exit:
	ats_uart_release();
	if (ret != 0) {
		endBurnProcess(-1, MSG_BURN_FAIL);
	}
	else {
		endBurnProcess(0, MSG_BURN_SUCCESS);
	}
	return ret;
}

int enterDfuMode(void) {
	const char* cmds[] = { "TL_ATS_IN", "TL_GET_VER", "TL_DFU_IN"};
	const int cmds_cnt = 3;

	struct sp_port* port = NULL;
	char ack[MAX_BUF_LEN] = { 0 };
	int ret, len;

	if (port_name == NULL) {
		my_printf("#<%d>请确认串口号类型!\n", MSG_ERROR);
		return -1;
	}

	port = ats_uart_init(port_name);
	if (!port) {
		my_printf("#<%d>串口对象初始化失败!\n", MSG_ERROR);
		ret = -1;
		goto exit;
	}

	ats_port = port;
    // 需要设置事件对象，否则串口不起作用
	sp_new_event_set(&ats_event);
	sp_add_port_events(ats_event, port, SP_EVENT_RX_READY);

	//ATS command mode
	for (int i = 0; i < cmds_cnt; i++) {
		len = sizeof(ack);
		ret = ats_uart_cmd_ack(cmds[i], ack, &len);
		if (ret != 0) {
			ret = -1;
			goto exit;
		}
		if (i == 2) {
			const char* pTag = "SUCCESS";
			if (strstr(ack, pTag) == NULL) {
				ret = -1;
				goto exit;
			}
		}
	}
	ret = 0;
	goto exit;

exit:
	ats_uart_release();
	return ret;
}

int processInput() {
	/**
	int ota_mode = 0;
	int ats_mode = 0;
	int c, opt_idx;
	char* cmd;
	static const char short_opts[] = "hvlp:b:c:u:";
	static const struct option long_opts[] = {
		{"help", 0, 0, 'h'},
		{"version", 0, 0, 'v'},
		{"list-ports", 0, 0, 'l'},
		{"port", 1, 0, 'p'},
		{"baudrate", 1, 0, 'b'},
		{"cmd", 1, 0, 'c'},
		{"upgrade", 1, 0, 'u'},
	};

	cmd = argv[0];
	if (argc < 2) {
		usage(cmd);
		return 0;
	}

	while ((c = getopt_long(argc, argv, short_opts, long_opts, &opt_idx)) != -1) {
		switch (c) {
		case 'h':
			usage(cmd);
			return 0;
		case 'v':
			printf("Version: %s\n", VERSION);
			return 0;
		case 'l':
			ats_uart_list_port();
			return 0;
		case 'p':
			port_name = optarg;
			dbg("port_name '%s'\n", port_name);
			break;
		case 'u':
			fw_name = optarg;
			ota_mode = 1;
			dbg("fw_name '%s'\n", fw_name);
			break;
		case 'c':
			ats_cmd = optarg;
			ats_mode = 1;
			dbg("ats_cmd '%s'\n", ats_cmd);
			break;
		case 'b':
			baudrate = (int)strtol(optarg, NULL, 10);
			dbg("set baudrate as %d\n", baudrate);
			break;
		default:
			usage(cmd);
			return 1;
		}
	}

	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);
	signal(SIGABRT, signal_handler);

	if (ats_mode) {
		process_ats_command();
	}
	else if (ota_mode) {
		process_fw_upgrade();
	}
	**/

	return 0;
}

int testBurnProcess() {
	/*
	const char* comName = "COM11";
	const char* fwName = "E:\\temp-files\\VS\\demo\\Burn_Tool\\x64\\Debug\\XG_BT_FW_3nod_240814_0401_Test_DFU.bin";
	port_name = (char*) comName;
	fw_name = (char*)fwName;
	process_fw_upgrade();
	**/
	return 0;
}


int main(int argc, char** argv)
{	
	// 设置内存共享标记为:未结束状态
	mIsEnd = false;
	
	// 分析传入的参数(警告:调用此模块时,必须按顺序传入参数,否则不响应)
	port_name = argv[1];
	fw_name = argv[2];
	binTypeValue = atoi(argv[3]);
	mmShareName = argv[4];
	
	// 初始化共享内存对象
	mShareProxy.initMMShare(mmShareName);

	// 提示状态
	showBurnState(BURN_STATE_INIT);
	// 提示参数信息 
	my_printf("#<%d>串口类型=%s\n", MSG_INFO, port_name);
	my_printf("#<%d>文件名=%s\n", MSG_INFO, fw_name);
	my_printf("#<%d>升级类型:%d\n", MSG_INFO, binTypeValue);
	my_printf("#<%d>共享内存数据名:%s\n", MSG_INFO, mmShareName);

	my_printf("#<%d>进入dfu模式!\n", MSG_INFO);
	int ret = enterDfuMode();
	if (ret != 0) {
		my_printf("#<%d>进入dfu模式失败,退出烧入!\n", MSG_ERROR);
		endBurnProcess(-1, "烧入失败!");
		return -1;
	} 
	my_printf("#<%d>进入dfu模式成功!\n", MSG_INFO);
	my_printf("#<%d>开始烧入:\n", MSG_INFO);
	process_fw_upgrade();

	return 0;
}


